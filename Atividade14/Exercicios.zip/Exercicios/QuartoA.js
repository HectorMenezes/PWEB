const fs = require('fs');
fs.readFile('file.txt', (err, data) => {
    if(err) throw err;
    console.log(data.toString());
});

for(let i = 0; i< 11; i++){
    console.log('Segunda Parte=' + i);
}