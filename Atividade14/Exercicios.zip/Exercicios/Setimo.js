var http = require('http')

var server = http.createServer(function (req, res) {
    var opcao = req.url;
    if(opcao == '/historia'){
        res.end("<html><body>Historia Fatec Sorocaba</body></html>");
    } else if(opcao == '/cursos'){
        res.end("<html><body>Cursos Fatec Sorocaba</body></html>");
    } else if(opcao == '/professores'){
        res.end("<html><body>Professores da Fatec Sorocaba como q entra aqui</body></html>");
    } else{
        res.end("<html><body>Site Fatec Sorocaba</body></html>");
    }
});
//Escuta a porta 300
server.listen(3000);