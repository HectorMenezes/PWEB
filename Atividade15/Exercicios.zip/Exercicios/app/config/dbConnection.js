module.exports = function (){
    const mysql = require('mysql');
    return connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'password',
        database: 'site_fatec'

    });
}